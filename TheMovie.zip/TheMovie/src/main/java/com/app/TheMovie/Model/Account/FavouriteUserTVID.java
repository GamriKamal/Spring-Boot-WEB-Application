package com.app.TheMovie.Model.Account;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class FavouriteUserTVID {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String TVID, userId;
    private String userName, movieName;

    @ManyToOne
    @JoinColumn(name = "userAccountID", nullable = false)
    private UserAccount userAccount;

    public FavouriteUserTVID(String TVID, String userId, String userName, String movieName) {
        this.TVID = TVID;
        this.userId = userId;
        this.userName = userName;
        this.movieName = movieName;
    }
}
