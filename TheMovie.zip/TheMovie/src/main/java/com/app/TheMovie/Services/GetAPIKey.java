package com.app.TheMovie.Services;

public class GetAPIKey {
    private final String API_Access_Key = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwMzU5OGQ5MzYyMDUyZDBmMmJjNTFmZGJjYzA2MTZiMSIsInN1YiI6IjY0YjUyZDJkMTIxOTdlMDEzOTk1M2Y5YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.oQVP1A60UVJOfbqqQi5Qi8v0sprhruG_SimBRcXUlVM";

    public String getAPI_Access_Key(){
        return API_Access_Key;
    }
}
