document.getElementById('showVideoButton').addEventListener('click', function() {
    document.getElementById('videoContainer').classList.remove('hidden');
});